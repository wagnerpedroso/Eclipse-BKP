package com.devinhouse.pcpbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcpBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
