package com.devinhouse.pcpbackend.dto;

import lombok.Getter;

@Getter
public class ClassArchiveDto {

	public Long classId;
    public boolean archived;
}
