package com.devinhouse.pcpbackend.converter;

import com.devinhouse.pcpbackend.dto.ClassCreateDto;
import com.devinhouse.pcpbackend.model.ClassEntity;


public class CourseClassConverter {
	
	
}
